var searchData=
[
  ['keypad_5fcontrol_5fenabled',['keypad_control_enabled',['../structScriptEnvironment.html#a48cd3fc2350cbe682b3a64f3ac2341cf',1,'ScriptEnvironment']]],
  ['keypad_5foverride_5fdirection',['keypad_override_direction',['../structScriptEnvironment.html#aedd9228382df05c57a61b328d5c1ba52',1,'ScriptEnvironment']]],
  ['kings_5frock',['kings_rock',['../structMoveDataFlags.html#ae91afbb807c40b16b08023befe1ecd1c',1,'MoveDataFlags']]]
];

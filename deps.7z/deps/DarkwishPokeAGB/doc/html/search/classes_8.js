var searchData=
[
  ['learnsetentry',['LearnsetEntry',['../structLearnsetEntry.html',1,'']]],
  ['linkbattlerecord',['LinkBattleRecord',['../structLinkBattleRecord.html',1,'']]],
  ['linkbattlerecords',['LinkBattleRecords',['../structLinkBattleRecords.html',1,'']]]
];

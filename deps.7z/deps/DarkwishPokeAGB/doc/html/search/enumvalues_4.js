var searchData=
[
  ['pokemon_5flanguage_5fde',['POKEMON_LANGUAGE_DE',['../pokemon_2data_8h.html#ac830adec4dc112ed7f6590443a45489da18c1e3daa0e6080523445ba91bc608be',1,'data.h']]],
  ['pokemon_5flanguage_5fen',['POKEMON_LANGUAGE_EN',['../pokemon_2data_8h.html#ac830adec4dc112ed7f6590443a45489da5476caea5a1466a6993e71492a0fab25',1,'data.h']]],
  ['pokemon_5flanguage_5fes',['POKEMON_LANGUAGE_ES',['../pokemon_2data_8h.html#ac830adec4dc112ed7f6590443a45489da05f3291822ea3c8638517183fac40e17',1,'data.h']]],
  ['pokemon_5flanguage_5ffr',['POKEMON_LANGUAGE_FR',['../pokemon_2data_8h.html#ac830adec4dc112ed7f6590443a45489da00ebcb75ec31cccf650009ac7378919c',1,'data.h']]],
  ['pokemon_5flanguage_5fit',['POKEMON_LANGUAGE_IT',['../pokemon_2data_8h.html#ac830adec4dc112ed7f6590443a45489dadff9d34b2bf7ae5ef078d2f9aae51df2',1,'data.h']]],
  ['pokemon_5flanguage_5fja',['POKEMON_LANGUAGE_JA',['../pokemon_2data_8h.html#ac830adec4dc112ed7f6590443a45489da0599d3ad0849b553c41c08232c86e3a6',1,'data.h']]],
  ['pokemon_5flanguage_5fko',['POKEMON_LANGUAGE_KO',['../pokemon_2data_8h.html#ac830adec4dc112ed7f6590443a45489da820b8adc2a4b7db04a335a2f9927ad3a',1,'data.h']]]
];

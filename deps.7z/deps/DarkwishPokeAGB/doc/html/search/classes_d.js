var searchData=
[
  ['ramscript',['RamScript',['../structRamScript.html',1,'']]],
  ['ramscriptdata',['RamScriptData',['../structRamScriptData.html',1,'']]],
  ['reg_5fbgcnt',['REG_BGCNT',['../structREG__BGCNT.html',1,'']]],
  ['roamer',['Roamer',['../structRoamer.html',1,'']]],
  ['rotscaleframe',['RotscaleFrame',['../structRotscaleFrame.html',1,'']]]
];

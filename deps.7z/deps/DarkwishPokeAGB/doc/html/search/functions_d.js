var searchData=
[
  ['oac_5fnullsub',['oac_nullsub',['../graphics_2sprites_8h.html#a6416a7cc27397f2dd57043cd5949eaa8',1,'sprites.h']]],
  ['oac_5fpingpong',['oac_pingpong',['../graphics_2sprites_8h.html#a977269b792c46440587e4ec2b770bacb',1,'sprites.h']]],
  ['obj_5fapply_5fbldpalfade',['obj_apply_bldpalfade',['../graphics_2sprites_8h.html#ae7f6b0f3e9ce838fcdf187bf1a729468',1,'sprites.h']]],
  ['obj_5fdelete',['obj_delete',['../graphics_2sprites_8h.html#a81b934e2e39e8c8ef89ad29693db2edb',1,'sprites.h']]],
  ['obj_5ffree',['obj_free',['../graphics_2sprites_8h.html#ad9065a4ca12bea13a151080addfff175',1,'sprites.h']]],
  ['obj_5fid_5fset_5frotscale',['obj_id_set_rotscale',['../graphics_2sprites_8h.html#a83724ba52e1458e0934a87164b632b44',1,'sprites.h']]],
  ['oe_5factive_5flist_5fremove',['oe_active_list_remove',['../effects_8h.html#accc93d1b26a622ac79ced67742dc9e8a',1,'effects.h']]],
  ['oe_5fexec',['oe_exec',['../effects_8h.html#aa83f18e80a4bb343462ab4825ef0649d',1,'effects.h']]],
  ['oe_5fstop',['oe_stop',['../effects_8h.html#a68580ac0f42b8be2b4f9ac3dc6d7a647',1,'effects.h']]],
  ['oldgetflagpointer',['OldGetFlagPointer',['../overworld_2script_8h.html#ae9557f5a637d7c8722bcea5bb7de376e',1,'script.h']]],
  ['oldgetvarpointer',['OldGetVarPointer',['../overworld_2script_8h.html#af62c988da1ac9440e423a0a4d6283356',1,'script.h']]],
  ['outline_5fbox',['outline_box',['../string_8h.html#ad8dc27a945f29df391c0a9644cede52e',1,'string.h']]],
  ['overworld_5ffree_5fbgmaps',['overworld_free_bgmaps',['../background_8h.html#a8ca61ee3f8bde88dd15bd0f6590c6083',1,'background.h']]]
];

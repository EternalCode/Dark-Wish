var searchData=
[
  ['id',['id',['../structWarpData.html#a420cc40042c20252ac13209d17452f1c',1,'WarpData']]],
  ['ids',['ids',['../structScrollArrows.html#a4ba846999010dc6052f7d5270b2d651c',1,'ScrollArrows']]],
  ['index',['index',['../structSignpostData.html#a87bce9435d10dd7e798ab7c599d103d7',1,'SignpostData']]],
  ['isegg',['isEgg',['../structBoxPokemon.html#a42db38cc683e516cd70dfbadbee102c6',1,'BoxPokemon']]],
  ['item',['Item',['../structTrainerPokemonBase.html#af18232905cf97ce0a46b0fd6f576a09f',1,'TrainerPokemonBase::Item()'],['../structSignpostData.html#af4ca378b2b45a8c310bf5ed4541e80dc',1,'SignpostData::item()']]],
  ['items',['items',['../item_8h.html#aa5f24ffe64aea1ddcd92d508e6a90587',1,'item.h']]]
];

/**
 * @file
 * @brief Overworld characters.
 */

#ifndef POKEAGB_OVERWORLD_NPC_H_
#define POKEAGB_OVERWORLD_NPC_H_

#include <pokeagb/types.h>
#include <pokeagb/common.h>
#include <pokeagb/graphics/sprites.h>

POKEAGB_BEGIN_DECL

/**
 * The player's NPC local ID.
 */
#define NPC_LOCAL_ID_PLAYER 0xFF

/**
 * Invalid NPC state ID.
 */
#define NPC_STATE_ID_MAX 0x10

/**
 * An NPC in the overworld.
 */
struct MapObject {
    /*0x00*/ u32 active:1;
             u32 mapobj_bit_1:1;
             u32 mapobj_bit_2:1;
             u32 mapobj_bit_3:1;
             u32 mapobj_bit_4:1;
             u32 mapobj_bit_5:1;
             u32 mapobj_bit_6:1;
             u32 mapobj_bit_7:1;
    /*0x01*/ u32 mapobj_bit_8:1;
             u32 mapobj_bit_9:1;
             u32 mapobj_bit_10:1;
             u32 mapobj_bit_11:1;
             u32 mapobj_bit_12:1;
             u32 mapobj_bit_13:1;
             u32 mapobj_bit_14:1;
             u32 mapobj_bit_15:1;
    /*0x02*/ u32 mapobj_bit_16:1;
             u32 mapobj_bit_17:1;
             u32 mapobj_bit_18:1;
             u32 mapobj_bit_19:1;
             u32 mapobj_bit_20:1;
             u32 mapobj_bit_21:1;
             u32 mapobj_bit_22:1;
             u32 mapobj_bit_23:1;
    /*0x03*/ u32 mapobj_bit_24:1;
             u32 mapobj_bit_25:1;
             u32 mapobj_bit_26:1;
             u32 mapobj_bit_27:1;
             u32 mapobj_bit_28:1;
             u32 mapobj_bit_29:1;
             u32 mapobj_bit_30:1;
             u32 mapobj_bit_31:1;
    /*0x04*/ u8 spriteId;
    /*0x05*/ u8 graphicsId;
    /*0x06*/ u8 animPattern;
    /*0x07*/ u8 trainerType;
    /*0x08*/ u8 localId;
    /*0x09*/ u8 mapNum;
    /*0x0A*/ u8 mapGroup;
    /*0x0B*/ u8 mapobj_unk_0B_0:4;
             u8 elevation:4;
    /*0x0C*/ struct Coords16 coords1;
    /*0x10*/ struct Coords16 currentCoords;
    /*0x14*/ struct Coords16 coords3;
    /*0x18*/ u8 direction;

    /*0x19*/ union __attribute__((packed)) {
        u8 as_byte;
        struct __attribute__((packed)) {
            u8 x:4;
            u8 y:4;
        } __attribute__((aligned (1))) as_nybbles;
    } __attribute__((aligned (1))) range;
    /*0x1A*/ u8 mapobj_unk_1A;
    /*0x1B*/ u8 oamid2;
    /*0x1C*/ u8 state;
    /*0x1D*/ u8 sight_distance;
    /*0x1E*/ u8 tile_to;
    /*0x1F*/ u8 tile_from;
    /*0x20*/ u8 mapobj_unk_20;
    /*0x21*/ u8 mapobj_unk_21;
    /*0x22*/ u8 animId;
    /*size = 0x24*/
};

/**
 * The player's movement state.
 */
struct PlayerAvatar {
    /*0x00*/ u8 flags;
    /*0x01*/ u8 bike;
    /*0x02*/ u8 running2;
    /*0x03*/ u8 running1;
    /*0x04*/ u8 spriteId;
    /*0x05*/ u8 mapObjectId;
    u8 lock;
    /*0x07*/ u8 gender;
    u8 acroBikeState;
    u8 unk9;
    u8 bikeFrameCounter;
    u8 fieldB;
    u32 fieldC;
    u32 field10;
    u32 field14;
    u8 field18;
    u8 field19;
    u16 field1A;
    u16 most_recent_override_tile;
};

/**
 * An NPC in the ROM.
 */
struct MapObjectTemplate {
    u8 localId;
    u8 graphicsId;
    u8 rival;
    u8 field3;
    u16 x;
    u16 y;
    u8 elevation;
    u8 movementType;
    u8 movement_area;
    u8 fieldB;
    u8 trainer_or_mapnumber;
    u8 fieldD;
    u8 sight_distance_or_mapbank;
    u8* script;
    u16 flagId;
    u16 field16;
};


/**
 * The player's movement state.
 *
 * @address{BPRE,02037078}
 */
extern struct PlayerAvatar gPlayerAvatar;

/**
 * Currently loaded NPCs.
 *
 * @address{BPRE,02036E38}
 */
extern struct MapObject gMapObjects[16];

/**
 * Reset NPC state with no checks.
 *
 * @address{BPRE,08063D34}
 */
POKEAGB_EXTERN u8 npc_half_reset_no_checks(struct MapObject* npc);

/**
 * Reset NPC when state->bitfield & 0x40
 *
 * @address{BPRE,08063D1C}
 */
POKEAGB_EXTERN void npc_half_reset(struct MapObject* npc);

/**
 * Set the NPC to have the given state (applymovement values) and apply associated animation.
 *
 * @address{BPRE,08063CA4}
 */
POKEAGB_EXTERN int npc_set_state_2(struct MapObject* npc, u8 state);

/**
 * Reset the NPC when state->bitfield & 0x80 (set by some tile behaviors)
 *
 * @address{BPRE,08063D7C}
 */
POKEAGB_EXTERN u8 npc_half_reset_when_bit7_is_set(struct MapObject* npc);

/**
 * Find an NPC given their local ID on a given map and bank.
 *
 * @address{BPRE,0805FD5C}
 */
POKEAGB_EXTERN struct MapObjectTemplate* rom_npc_by_local_id_and_map(u8 local_id, u8 map, u8 bank);

/**
 * Spawn a new NPC.
 *
 * @address{BPRE,0805E72C}
 */
POKEAGB_EXTERN u8 npc_instanciation_something(struct MapObjectTemplate*,
                                              u8 map,
                                              u8 bank,
                                              s16 x_shift,
                                              s16 y_shift);

/**
 * Change the NPC's sprite.
 *
 * @address{BPRE,0805F060}
 */
POKEAGB_EXTERN void npc_change_sprite(struct MapObject* npc, u8 sprite);

/**
 * Make the NPC face a given direction.
 *
 * @address{BPRE,0805F218}
 */
POKEAGB_EXTERN void npc_turn(struct MapObject* npc, u8 direction);

/**
 * Exclamation mark animation over npc.
 *
 * @address{BPRE,08066920}
 */
POKEAGB_EXTERN void an_exclamation_mark(struct MapObject* npc, struct Sprite* obj);

/**
 * Translate a local ID to an NPC state ID.
 * Map and bank are ignored if local_id != NPC_LOCAL_ID_PLAYER.
 *
 * @param local_id A local ID (e.g. from applymovement).
 * @param map From this map number.
 * @param bank From this map bank number.
 * @return The NPC state id or NPC_STATE_ID_MAX on failure.
 *
 * @address{BPRE,0805DF60}
 */
POKEAGB_EXTERN u8 npc_id_by_local_id(u8 local_id, u8 map, u8 bank);

/**
 * set a direction an NPC will turn
 *
 * @address{BPRE,0805FBDC}
 */
POKEAGB_EXTERN void FieldObjectSetDirection(struct MapObject* npc, u8 direction);

/**
 * set x and y coords given a direction to move
 *
 * @address{BPRE,08063A20}
 */
POKEAGB_EXTERN void MoveCoords(u8 direction, s16 *x, s16 *y);

/**
 * Translate a local ID to an NPC state ID.
 * Map and bank are ignored if local_id != NPC_LOCAL_ID_PLAYER.
 *
 * @param local_id A local ID (e.g. from applymovement).
 * @param map From this map number.
 * @param bank From this map bank number.
 * @param id Pointer to store the result at.
 * @return true if the lookup failed.
 *
 * @address{BPRE,0805DF84}
 */
POKEAGB_EXTERN bool npc_id_by_local_id_and_map_ret_success(u8 local_id, u8 map, u8 bank, u8* id);

POKEAGB_END_DECL

#endif /* POKEAGB_OVERWORLD_NPC_H_ */

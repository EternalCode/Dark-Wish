/**
 * @file
 * @brief Pokemon species.
 */

#ifndef POKEAGB_POKEMON_SPECIES_H_
#define POKEAGB_POKEMON_SPECIES_H_

#include <pokeagb/common.h>

#endif /* POKEAGB_POKEMON_SPECIES_H_ */

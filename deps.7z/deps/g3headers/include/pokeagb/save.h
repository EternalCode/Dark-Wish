#ifndef POKEAGB_SAVE_H_
#define POKEAGB_SAVE_H_

#include "save/block.h"
#include "save/flash.h"

#endif /* POKEAGB_SAVE_H_ */
